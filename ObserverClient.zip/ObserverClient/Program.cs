﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.NetworkInformation;
using System.Collections;


namespace ObserverClient
{
    class Program
    {
        /// <summary>
        /// The main entry point into the application
        /// </summary>
        /// <param name="args">Command line argument</param>
        /// 
        static void Main(string[] args)
        {
            // Register subject 1
            Subject subject1 = new Subject { SubscriptionId = "1", CacheId = "1", CacheData = "1" };
            subject1.NotifyChanged += s_testCacheObserver1NotifyChanged_One;
            // Tie the following event handler to any notifications received on this particular subject
            subject1.ExpirationType = Enums.enumExpirationType.Sliding;
            subject1.Register();

            // Register subject 2
            Subject subject2 = new Subject { SubscriptionId = "1", CacheId = "2", CacheData = "2" };
            // Tie the following event handler to any notifications received on this particular subject
            subject2.NotifyChanged += s_testCacheObserver1NotifyChanged_One;
            subject2.Register();

            // Register subject 3
            Subject subject3 = new Subject { SubscriptionId = "1", CacheId = "1", CacheData = "Boom!" };
            // Tie the following event handler to any notifications received on this particular subject
            subject3.NotifyChanged += s_testCacheObserver1NotifyChanged_Two;
            subject3.Change();

            // Unregister subject 2. Only subject 2's notification event should fire and the
            // notification should be specific about the operations taken on it
            subject2.Unregister();

            // Change subject 1's data.  Only subject 2's notification event should fire and the
            // notification should be specific about the operations taken on it
            subject1.CacheData = "Change Me";
            subject1.Change();

            // Hang out and let the system clean up after itself.  Events should only fire for those
            // objects that are self-unregistered.  The system is capable of maintaining itself.
            Console.ReadKey();
        }

        /// <summary>
        /// Notifications are received from the Subject whenever changes have occurred.
        /// </summary>
        /// <typeparam name="T">The generic type parametner</typeparam>
        /// <param name="notifyInfo">The subject that changed due to an action that was taken on it</param>
        /// <param name="action">The specific action that was taken</param>
        /// 
        static void s_testCacheObserver1NotifyChanged_One<T>(T notifyInfo, Enums.enumSubjectAction action)
        {
            var data = notifyInfo;
        }

        /// <summary>
        /// Notifications are received from the Subject whenever changes have occurred.
        /// </summary>
        /// <typeparam name="T">The generic type parametner</typeparam>
        /// <param name="notifyInfo">The subject that changed due to an action that was taken on it</param>
        /// <param name="action">The specific action that was taken</param>
        /// 
        static void s_testCacheObserver1NotifyChanged_Two<T>(T notifyInfo, Enums.enumSubjectAction action)
        {
            var data = notifyInfo;
        }
    }
}