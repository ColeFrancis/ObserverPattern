﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Globalization;

namespace ObserverClient
{
    /// <summary>
    /// The SubjectDecorator class provides additional operations that the Subject class
    /// should be aware of but fall outside its immediate scope of attention.
    /// </summary>
    public class LifetimeManager
    {
        #region Member Variables

        private Timer timer = new Timer();

        #endregion

        #region Properties

        public object SubscriptionId { get; set; }
        public object CacheId { get; set; }
        public object CacheData { get; set; }
        public int ExpirationValue { get; set; }
        public Enums.enumExpirationType ExpirationType { get; set; }
        public Enums.enumTimePrecision TimePrecision { get; set; }
        public DateTime ExpirationStart { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Fires when the object's time to live has expired
        /// </summary>
        /// <param name="sender">The sender parameters</param>
        /// <param name="e">The elapsed event arguments</param>
        void s_TimeHasExpired(object sender, ElapsedEventArgs e)
        {
            // Delete the Observer Cache and notify the caller
            NotifyObjectExpired();
        }

        /// <summary>
        /// The delegate for the NotificationChangeEventHandler event
        /// </summary>
        /// <typeparam name="T">The generic parameter type</typeparam>
        /// <param name="notifyinfo">The generic data</param>
        /// <param name="action">The action being performed</param>
        public delegate void NotifyObjectExpiredHandler();

        /// <summary>
        /// Provides expiration monitoring capabilities for itself (self-maintained expiration)
        /// </summary>
        internal void MonitorExpiration()
        {
            double milliseconds = 0;

            switch (this.TimePrecision)
            {
                case Enums.enumTimePrecision.Milliseconds:
                    {
                        milliseconds = DateTime.Now.Subtract(DateTime.Now.AddMilliseconds(this.ExpirationValue)).TotalMilliseconds;
                        break;
                    }
                case Enums.enumTimePrecision.Seconds:
                    {
                        milliseconds = DateTime.Now.Subtract(DateTime.Now.AddSeconds(this.ExpirationValue)).TotalMilliseconds;
                        break;
                    }
                case Enums.enumTimePrecision.Minutes:
                    {
                        milliseconds = DateTime.Now.Subtract(DateTime.Now.AddMinutes(this.ExpirationValue)).TotalMilliseconds;
                        break;
                    }
                case Enums.enumTimePrecision.Hours:
                    {
                        milliseconds = DateTime.Now.Subtract(DateTime.Now.AddHours(this.ExpirationValue)).TotalMilliseconds;
                        break;
                    }
                case Enums.enumTimePrecision.Days:
                    {
                        milliseconds = DateTime.Now.Subtract(DateTime.Now.AddDays(this.ExpirationValue)).TotalMilliseconds;
                        break;
                    }
                case Enums.enumTimePrecision.Months:
                    {
                        milliseconds = DateTime.Now.Subtract(DateTime.Now.AddMonths(this.ExpirationValue)).TotalMilliseconds;
                        break;
                    }
                case Enums.enumTimePrecision.Years:
                    {
                        milliseconds = DateTime.Now.Subtract(DateTime.Now.AddYears(this.ExpirationValue)).TotalMilliseconds;
                        break;
                    }
                default:
                    {
                        break;
                    }

            }

            if(timer.Interval > 0)
            {
                timer.Stop();
                timer.Dispose();
                timer = new Timer(Math.Abs(milliseconds));
                timer.Elapsed += new ElapsedEventHandler(s_TimeHasExpired);
                timer.Enabled = true;
            }
            else
            {
                timer.Elapsed += new ElapsedEventHandler(s_TimeHasExpired);
                timer.Enabled = true;
            }
        }

        #endregion
        
        #region Events

        /// <summary>
        /// Handles the change notification event
        /// </summary>
        public event NotifyObjectExpiredHandler NotifyObjectExpired;

        #endregion        
    }
}
