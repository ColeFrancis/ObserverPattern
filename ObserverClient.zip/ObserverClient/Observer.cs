﻿using System;
using System.Collections.Generic;


namespace ObserverClient
{
    /// <summary>
    /// The abstract observer base class
    /// </summary>
    public static class Observer
    {
        #region Member Variables

        /// <summary>
        /// The global data cache
        /// </summary>
        private static List<LifetimeManager> _data = new List<LifetimeManager>();

        #endregion

        #region Methods

        /// <summary>
        /// Provides CRUD operations on the global cache object
        /// </summary>
        /// <param name="data">The payload data</param>
        /// <param name="action">The enumeration action, which handles basic CRUD operations</param>
        /// <returns>A boolean; true if successful; false if unsuccessful</returns>
        internal static bool Update(LifetimeManager data, Enums.enumSubjectAction action)
        {
            try
            {
                object o = new object();

                // This locks the critical section, just in case a timer even fires at the same
                // time the main thread's operation is in action.
                lock (o)
                {
                    switch (action)
                    {
                        case Enums.enumSubjectAction.AddChange:
                            {
                                // Finds the original object and removes it, and then it re-adds it to the list
                                _data.RemoveAll(a => a.SubscriptionId == data.SubscriptionId && a.CacheData == data.CacheId);
                                _data.Add(data);
                                break;
                            }
                        case Enums.enumSubjectAction.RemoveChild:
                            {
                                // Finds the entry in the list and removes it
                                _data.RemoveAll(a => a.SubscriptionId == data.SubscriptionId && a.CacheData == data.CacheId);
                                break;
                            }
                        case Enums.enumSubjectAction.RemoveParent:
                            {
                                // Finds the entry in the list and removes it
                                _data.RemoveAll(a => a.SubscriptionId == data.SubscriptionId);
                                break;
                            }
                        default:
                            {
                                // This is useless
                                break;
                            }
                    }

                    return true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion
    }
}
