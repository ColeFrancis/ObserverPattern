﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverClient.Entity
{
    public interface ISubjectOperation
    {
        void Register();
        void Unregister<T>();
        void Unregister<T>(T item);
    }
}
