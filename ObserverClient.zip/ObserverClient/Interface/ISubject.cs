﻿using System;
using System.Collections.Generic;


namespace ObserverClient.Interface
{
    /// <summary>
    /// This is the Subject Interface
    /// </summary>
    public interface ISubject
    {
        #region Interface Operations

        object SubscriptionId { get; set; }
        object CacheId { get; set; }
        object CacheData { get; set; }
        int ExpirationValue { get; set; }
        Enums.enumTimePrecision TimePrecision { get; set; }
        DateTime ExpirationStart { get; set; }
        Enums.enumExpirationType ExpirationType { get; set; }
        void Register();
        void Unregister();

        #endregion
    }
}
