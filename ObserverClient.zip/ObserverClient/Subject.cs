﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObserverClient.Interface;


namespace ObserverClient
{
    /// <summary>
    /// This is the Subject Class, which provides the ability to register and unregister and object.
    /// </summary>
    public class Subject : LifetimeManager,  ISubject
    {
        #region Events

        /// <summary>
        /// Handles the change notification event
        /// </summary>
        public event NotifyChangeEventHandler<object> NotifyChanged;

        #endregion
        
        #region Methods

        /// <summary>
        /// The delegate for the NotificationChangeEventHandler event
        /// </summary>
        /// <typeparam name="T">The generic parameter type</typeparam>
        /// <param name="notifyinfo">The generic data</param>
        /// <param name="action">The action being performed</param>
        public delegate void NotifyChangeEventHandler<T>(T notifyinfo, Enums.enumSubjectAction action);

        /// <summary>
        /// The register method.  This adds the entry and data to the Observer's data cache
        /// and then provides notification of the event to the caller if it's successfully added.
        /// </summary>
        public void Register()
        {
            try
            {
                if (Observer.Update(this, Enums.enumSubjectAction.AddChange))
                {
                    this.NotifyChanged(this, Enums.enumSubjectAction.AddChange);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// The unregister method.  This removes the entry and data in the Observer's data cache
        /// and then provides notification of the event to the caller if it's successfully removed.
        /// </summary>
        public void Unregister()
        {
            try 
	        {	        
		        if (this.SubscriptionId != null && this.CacheId == null)
                {
                    Observer.Update(this, Enums.enumSubjectAction.RemoveParent);
                    this.NotifyChanged(this, Enums.enumSubjectAction.RemoveParent);
                }
                else if (this.SubscriptionId != null && this.CacheId != null)
                {
                    Observer.Update(this, Enums.enumSubjectAction.RemoveChild);
                    this.NotifyChanged(this, Enums.enumSubjectAction.RemoveChild);
                }
	        }
	        catch (Exception)
	        {
		        throw;
	        }
        }

        /// <summary>
        /// The change method.  This modifies the entry and data to the Observer's data cache
        /// and then provides notification of the event to the caller if successful.
        /// </summary>
        /// <remarks>
        /// This is really the same as the register method, but it provides a better user experience
        /// when we differentiate between registering an object for the very first time versus modifying it.
        /// It's really just a matter of semantics.
        /// </remarks>
        public void Change()
        {
            try
            {
                if (Observer.Update(this, Enums.enumSubjectAction.AddChange))
                {
                    if(this.ExpirationType == Enums.enumExpirationType.Sliding)
                    {
                        this.ExpirationStart = DateTime.Now;
                        this.MonitorExpiration();
                    }

                    this.NotifyChanged(this, Enums.enumSubjectAction.AddChange);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// The event handler for object expiration notifications. It calls unregister for the current object.
        /// </summary>
        void s_ExpiredUnregisterNow()
        {
            // Unregisters itself
            this.Unregister();
        }

        #endregion

        #region Constructor(s)

        /// <summary>
        /// The Subject's default constructor (i.e. all the values relating to cache expiration are defaulted to 1 minute).
        /// </summary>
        public Subject()
        {
            this.ExpirationType = Enums.enumExpirationType.Basic;
            this.ExpirationValue = 1;
            this.TimePrecision = Enums.enumTimePrecision.Minutes;
            this.ExpirationStart = DateTime.Now;

            this.NotifyObjectExpired += s_ExpiredUnregisterNow;
            this.MonitorExpiration();
        }

        /// <summary>
        /// The overloaded Subject constructor
        /// </summary>
        /// <param name="expirationStart">The expiration start time (e.g. the default in DateTime.Now)</param>
        /// <param name="expirationType">This decides whether the ExpirationStartTime gets updated each time a SubscriptionId and CacheId gets
        ///                              updated.  If sliding, then then the date gets updated when the data is changed.
        ///                              In other words, the expiration time is reset; otherwise, it's a fixed expiration
        ///                              and does not get reset whenever the data for the SubscriptionId and CacheId is updated.
        /// <param name="expirationValue">The value to tie the expiration time to (e.g. 10 minutes, 30 seconds, 1 hour, etc...)</param>
        /// <param name="timePrecision">The expiration type (e.g. seconds, minutes, hours, etc...)</param></param>
        public Subject(Enums.enumExpirationType expirationType, int expirationValue, Enums.enumTimePrecision timePrecision)
        {
            this.ExpirationType = expirationType;
            this.ExpirationValue = expirationValue;
            this.TimePrecision = timePrecision;
            this.ExpirationStart = DateTime.Now;

            this.NotifyObjectExpired += s_ExpiredUnregisterNow;
            this.MonitorExpiration();
        }

        #endregion
    }
}