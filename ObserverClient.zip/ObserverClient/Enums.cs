﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverClient
{
    /// <summary>
    /// This is the class that holds all the enumerations for the application
    /// </summary>
    public class Enums
    {
        #region Enumerations

        /// <summary>
        /// Expiration type 
        /// </summary>
        public enum enumExpirationType
        {
            Basic = 0,
            Sliding = 1
        };

        /// <summary>
        /// Subject action
        /// </summary>
        public enum enumSubjectAction
        {
            AddChange = 0,
            RemoveChild = 1,
            RemoveParent = 2
        }

        /// <summary>
        /// The time precision
        /// </summary>
        public enum enumTimePrecision
        {
            Years = 0,
            Months = 1,
            Days = 2,
            Hours = 3,
            Minutes = 4,
            Seconds = 5,
            Milliseconds = 6
        }

        #endregion
    }
}
